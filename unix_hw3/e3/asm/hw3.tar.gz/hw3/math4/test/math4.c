int main() {
    int val1 = 2;
    int val2 = 3;
    int val3 = 10;
    int val4 = (val1 * -5) / (-val2 % val3);
}
